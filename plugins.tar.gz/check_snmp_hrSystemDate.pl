#!/usr/bin/perl
# nagios: +epn
#
# (P) & (C) 2009 Venyon <operations@venyon.com>
#
# Authors:      Dr. Peter Bieringer (bie)

# Changes:
# 20091009/bie: initial
# 20091012/bie: finish implementation
# 20091013/bie: improve failure handling
# 20091105/bie: improve handling for systems which are not sending timezone information
# 20091106/bie: use only time after retrieving result for comparing
# 20091106/bie: major improvement of the automatically timezone shift detection
# 20100714/bie: remove PROGNAME from output
# 20131011/bie: add SNMPv3 support


=head1 NAME

venyon_nagios_check_snmp_hrSystemDate.pl - checks hrSystemDate via snmp

=head1 SYNOPSIS

./nagios_check_snmp_hrSystemDate.pl -H <ip_address> [-C community] [-P snmp version] [-t timeout] [-h] [-v] [-V] [-w warningdelta] [-c criticaldelta] [-U]
                                      [-u <SNMPv3 user>]
                                      [-a <SNMPv3 auth proto>]
                                      [-A <SNMPv3 auth pass>]
                                      [-x <SNMPv3 priv proto>]
                                      [-X <SNMPv3 priv pass>]
                                      [-l <SNMPv3 security level>]

=head1 OPTIONS

=over 5

=item -w

    delta in seconds for warning level

=item -c

    delta in seconds for critical level

=item -U

    perform UTC check

=item -h

    Print detailed help screen

=item -V

    Print version information

=item -H

    Host name or IP Address

=item -P [1|2c|3]

    SNMP protocol version

=item -C

    Optional community string for SNMP communication (default is "public")

=item -t

    Seconds before connection times out (default: 10)

=item -v

    Show details for command-line debugging (Nagios may truncate output)

=back

=head1 DESCRIPTION

Checks hrSystemDate against local system time via SNMP

This plugin uses the 'snmpget' command included with the NET-SNMP package.
if you don't have the package installed, you will need to download it from
http://net-snmp.sourceforge.net before you can use this plugin.


=cut

use warnings;
use strict;
use Getopt::Long;
use Pod::Usage;
use SNMP 5.0;
use Time::Local;
use vars qw ($snmp_session);
use lib "/usr/lib/nagios/plugins/";
use lib "/usr/lib64/nagios/plugins/";
use utils qw(%ERRORS &print_revision);

check();

sub check {

    my $PROGNAME = 'venyon_check_snmp_hrSystemDate';
    my $VERSION  = '$Revision: 1 $';


    ################################################
    # set defaults
    my $timeout       = 30;
    my $snmpcommunity = "public";
    my $snmpversion   = "2c";

    ################################################
    # parse command line arguments
    my ($opt_H,$opt_h,$opt_v,$opt_t,$opt_V,$opt_C,$opt_P,$opt_w,$opt_c,$opt_U, $opt_a, $opt_A, $opt_x, $opt_X, $opt_l, $opt_u);
    Getopt::Long::Configure("no_ignore_case");
    GetOptions(
        "H=s"        => \$opt_H,
        "v"          => \$opt_v,
        "h"          => \$opt_h,
        "t=i"        => \$opt_t,
        "w=i"        => \$opt_w,
        "c=i"        => \$opt_c,
        "V"          => \$opt_V,
        "U"          => \$opt_U,
        "C=s"        => \$opt_C,
        "P=s"        => \$opt_P,
       "a=s"        => \$opt_a,
       "A=s"        => \$opt_A,
       "x=s"        => \$opt_x,
       "X=s"        => \$opt_X,
       "l=s"        => \$opt_l,
       "u=s"        => \$opt_u,
    );

    ########################################################
    if ($opt_V) {
        print_revision($PROGNAME, $VERSION);
        exit $ERRORS{'OK'};
    }

    ########################################################
    # set a timeout
    if(defined $opt_t) { $timeout = $opt_t; }
        $SIG{ALRM} = sub{
        print "CRITICAL: timeout after $timeout seconds.";
        exit $ERRORS{"CRITICAL"}; 
    };
    alarm($timeout);

    ################################################
    # just print the help message?
    if(defined $opt_h) {
        pod2usage( { -verbose => 1 } );
        exit $ERRORS{'OK'};
    }

    ################################################
    # should we be verbose?
    my $verbose  = 0;
    if(defined $opt_v) {
        $verbose   = 1;
    }

    ################################################
    # check for a valid hostname
    if(!defined $opt_H) {
        pod2usage( { -verbose => 1, -msg => "Error: -H <hostname> is a required option." } );
        exit $ERRORS{"UNKNOWN"}; 
    }

    ################################################
    # set snmp community
    if(defined $opt_C && $opt_C ne "" && $opt_C ne '$_HOSTSNMPCOMMUNITY$') {
        $snmpcommunity = $opt_C;
    }

    ################################################
    # set snmp protocol version
    if(defined $opt_P && $opt_P ne "" && $opt_P ne '$_HOSTSNMPVERSION$') {
        $snmpversion = $opt_P;
    }


    ################################################
    # create a session for conversing with the remote SNMP agent
    $snmp_session = new SNMP::Session(
        DestHost => $opt_H,
        Community => $snmpcommunity,
        Version   => $snmpversion,
        SecLevel  => $opt_l,
        AuthProto => $opt_a,
        AuthPass  => $opt_A,
        PrivProto => $opt_x,
        PrivPass  => $opt_X,
        SecName   => $opt_u
    );

    if(! defined $snmp_session) {
        print "UNKNOWN - can't create SNMP session to $opt_H\n";
        exit $ERRORS{"UNKNOWN"}; 
    };


    # HOST-RESOURCES-MIB::hrSystemDate.0 = ".1.3.6.1.2.1.25.1.2.0"
    my $rc = $snmp_session->get(".1.3.6.1.2.1.25.1.2.0");

    if(! defined $rc) {
        print "UNKNOWN - snmpget failed\n";
        exit $ERRORS{"UNKNOWN"}; 
    };


    ## Basic result checks
    # length
    if ((length($rc) != 11) && (length($rc) != 8)) {
        print "UNKNOWN - result has not 8 or 11 chars (only " . length($rc) . ")\n";
        exit $ERRORS{"UNKNOWN"}; 
    };

    # chars


    ## Split
    my @result;
    for (my $i = 0; $i < length($rc); $i++) {
        $result[$i+1] = ord(substr($rc,$i,1));
        # print $result[$i+1] . "\n";
    };


=head1 Format

hrSystemDate is defined using the syntax DateAndTime,
from SNMPv2-TC.   This type is defined as follows:

DateAndTime ::= TEXTUAL-CONVENTION
    DISPLAY-HINT "2d-1d-1d,1d:1d:1d.1d,1a1d:1d"
    STATUS       current
    DESCRIPTION
            "A date-time specification.

            field  octets  contents                  range
            -----  ------  --------                  -----
              1      1-2   year*                     0..65536
              2       3    month                     1..12
              3       4    day                       1..31
              4       5    hour                      0..23
              5       6    minutes                   0..59
              6       7    seconds                   0..60
                           (use 60 for leap-second)
              7       8    deci-seconds              0..9
              8       9    direction from UTC        '+' / '-'
              9      10    hours from UTC*           0..13
             10      11    minutes from UTC          0..59

            For example, Tuesday May 26, 1992 at 1:30:15 PM EDT would be
            displayed as:

                             1992-5-26,13:30:15.0,-4:0"
    SYNTAX       OCTET STRING (SIZE (8 | 11))

=cut

    my $year = $result[1] * 256 + $result[2];
    my $month = $result[3];
    my $day = $result[4];
    my $hour = $result[5];
    my $min = $result[6];
    my $sec = $result[7];
    my $dsec = $result[8];

    my $offset_hour = 0;
    my $offset_min  = 0;

    if (length($rc) == 11) {
        # timezone included
        $offset_hour = $result[10];
        $offset_min  = $result[11];
        if ($result[9] == 45) {
            # '-'
            $offset_hour = - $offset_hour;
        };
    };


    my $time_gm_remotehost = Time::Local::timegm($sec, $min, $hour, $day, $month - 1, $year - 1900);

    # Adjust remote host time by offset
    $time_gm_remotehost -= ($offset_hour * 60 + $offset_min) * 60;

    my $time_gm_localhost = time();

    print "Unixtime of remote host   : " . $time_gm_remotehost . "\n" if ($verbose);
    print "Unixtime of this   host   : " . $time_gm_localhost . "\n" if ($verbose);

    my $delta = $time_gm_localhost - $time_gm_remotehost;
    print "Delta                     : " . $delta . "\n" if ($verbose);

    my $delta_check = abs($delta);

    # Timezone shift detection for SNMP data containing no timezone
    my $flag_autodetect_tz_shift = 0;

    if (length($rc) != 11 && $delta != 0 ) {
        ## automagically detect Delta caused by timeshift for snmp values not containing timezone data

        if (int(abs($delta) / 3600) < 12) {
            # first, delta must be below 12 hours
            my $range = 5 * 60; # seconds
            printf "Timeshift auto-detect range: " . $range . "\n" if ($verbose);
            my $delta_timeshift = int((abs($delta) + $range) / 3600) * 3600;
            print "Timeshift auto-detect delta: " . $delta_timeshift . "\n" if ($verbose);

            if ( abs(abs($delta) - $delta_timeshift) < $range) {
                # second, delta should be below range
                $offset_hour = $delta_timeshift / 3600 * abs($delta) / $delta; # restore +/-
                $offset_min = $delta_timeshift % 3600;

                $delta_check = abs($delta) - $delta_timeshift;

                printf "Timeshift auto-detected   :  %+03d:%02d\n", $offset_hour, $offset_min if ($verbose);
                $flag_autodetect_tz_shift = 1;
            };
        };

    };

    print "Delta check               : " . $delta_check . "\n" if ($verbose);

    my $flag = 0;

    if (defined $opt_w) {
        if ($delta_check < $opt_w) {
            # nothing to do	
        } else {
            $flag = 1; # warning
        };
    };

    if (defined $opt_c) {
        if ($delta_check < $opt_c) {
            # nothing to do	
        } else {
            $flag = 2; # critical
        };
    };

    if (defined $opt_U) {
        if (($offset_hour * 60 + $offset_min) * 60 != 0) {
            $flag = 3; # offset not zero, UTC check is enabled
        };
    };

    my $hrSystemDate = sprintf "hrSystemDate: %04d-%02d-%02d %02d:%02d:%02d %+03d:%02d", $year, $month, $day, $hour, $min, $sec, $offset_hour, $offset_min;

    if ($flag == 2) {
        print "CRITICAL - delta to local unixtime is: " . $delta . " seconds (" . $hrSystemDate . ")\n";
        exit $ERRORS{"CRITICAL"}; 
    };

    if ($flag == 1) {
        print "WARNING - delta to local unixtime is: " . $delta . " seconds (" . $hrSystemDate . ")\n";
        exit $ERRORS{"WARNING"}; 
    };

    if ($flag == 3) {
        if ($flag_autodetect_tz_shift == 1) {
            printf "WARNING - timezone is not UTC, offset is: %+03d:%02d (" . $hrSystemDate . " TZ shift autodetected)\n", $offset_hour, $offset_min;
        } else {
            printf "WARNING - timezone is not UTC, offset is: %+03d:%02d (" . $hrSystemDate . ")\n", $offset_hour, $offset_min;
        }
        exit $ERRORS{"WARNING"}; 
    };

    if ($flag_autodetect_tz_shift == 1) {
        printf $hrSystemDate . " (TZ shift autodetected)\n";
        exit $ERRORS{"OK"}; 
    };

    printf $hrSystemDate . "\n";

    exit $ERRORS{"OK"}; 
}
