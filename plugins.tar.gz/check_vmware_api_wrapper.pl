#!/usr/bin/perl

$ENV{PERL_LWP_SSL_VERIFY_HOSTNAME} = 0;

# nagios: -epn

# check_vmware_api_wrapper.pl - protect your Nagios host against high cpu loads
# stemming from check_vmware_api.pl (or to be exact, from the XML parsing going
# on inside the VMware Perl API).
#
# This wrapper will allow you to enforce a maximum of simultaneously
# running check_vmware_api.pl processes, and thereby to spread the load over time.
#
# Basic idea:
# 1) Rename the original check_vmware_api.pl script to check_vmware_api.pl_cache
# 2) Rename this script to check_vmware_api.pl
# 3) Continue as planned
#
# USAGE: Override $debug using --cache-debug on the command line
# USAGE: Override $cache_time using --cache-time=XX on the command line
#
# TODO: This wrapper will leave a cache file in /tmp for each command line
# wrapped. This wrapper should execute a cleanup of stale cache files
# once in a while (at random invocations). rm /tmp/check_vmware_*.cache for now.

use warnings;
use strict;

my $username = whoami();

my $debug = 0;
my $debug_cache     = "";
my $esx_plugin_name = $0;
#$esx_plugin_name =~ s/check_vmware_api_wrapper.pl/check_vmware_api.pl/gmx;
$esx_plugin_name =~ s/check_vmware_api_wrapper.pl/check_esx3.pl/gmx;
die("no recursion!") if $0 eq $esx_plugin_name;
my $cache_time      = 11; 
my $unknown_log     = "/tmp/" . $esx_plugin_name . "_unknown_msgs." . $username . ".log";
my $cmdline         = "$esx_plugin_name '" . join("' '", @ARGV) . "'";

if ( $cmdline =~ /\-\-cache-debug/ ) {
	$debug = 1;
	$cmdline =~ s/\-\-cache\-debug//;
}

print_debug("Command line: $cmdline \n");

if ( $cmdline =~ /\-\-cache\-time\=(\d+)/ ) {
	$cache_time = $1;
	$cmdline =~ s/\-\-cache\-time\=(\d+)//;
}

$cmdline =~ s/^\s*|\s*$//g;

#print_debug("Command line to cache: $cmdline \n");

use Digest::MD5 qw( md5_hex );
my $hashCode = md5_hex( $cmdline );

my $cacheFile = "/tmp/check_vmware_$hashCode.$username.cache";
#print_debug("Cache file: " . $cacheFile . "\n");

my $now = time();
my $cache_stale = $now - $cache_time*60;

my @cache_stat = stat( "$cacheFile" );
# todo: parameter? 
#if (( "$cache_stat[9]" eq "" ) || ( $cache_stale > $cache_stat[9] )) {
#	print_debug("Cache file not found or too old, refreshing ... \n");
	refresh_cache($cmdline, $cacheFile, $esx_plugin_name);
#} else {
#	print_debug("Cache file fresh (" . localtime($cache_stat[9]) . "), using cache info\n");
#	replay_cache( $cacheFile );
#}


sub refresh_cache {
	my ($cmdline, $cacheFile, $esx_plugin_name) = @_;
	# First, surge protection ...
	# This is to make sure that we keep the load from the plugin stable,
	# as check_vmware_api.pl is both very cpu and bandwidth intensive
	my $tries_count    = 3;
	my $sleep_interval = 3;
	my $process_count;
	my $go = 0;
	for (my $try = 1; $try <= $tries_count ; $try++) {
		$process_count = `ps -eo comm | grep check_vmware_ap --count`;
		print_debug("processes running: $process_count\n");
		chomp($process_count);
		unless ($process_count > 25) {
			$go = 1;
			last;
		}
		print_debug("Too many $esx_plugin_name processes running ($process_count), try no. $try, retrying in $sleep_interval seconds ..\n");
		sleep $sleep_interval;
	}
	unless ($go) {
		# ok, then ... we'll give up for now and just replay the latest cached result once more
		if ( -e $cacheFile ) {
			replay_cache( $cacheFile );
		} else {
			# OK, too bad, no cache file we can draw on .. die crying
			print "CHECK_VMWARE_API.PL UNKNOWN: Too many $esx_plugin_name processes already running ($process_count), aborting\n";
			exit 3;
		}
	}
	# Activate timeout. The --timeout parameter to check_vmware_api.pl unfortunately typically
	# doesn't work, as it is only a timeout for every discrete blocking operation
	# inside the VMware API - not for the total running time of the plugin.
	# I.e. memctl and swap checks can take a minute in looping through the vms

	# Set this timeout somewhat lower (~20 sec) than the check_nrpe timeout value
	my $timeout = 100;
	my $output = "CHECK_VMWARE_API.PL UNKNOWN: No reply from $esx_plugin_name";
	my $exit_code = 3;
	eval {
		local $SIG{ALRM} = sub { die "alarm\n" }; # NB: \n required
		alarm $timeout;
		print_debug("executing: $cmdline, timeout: $timeout\n");
		# Let's spawn using nice - i.e. check_ping and check_http are easily affected by high loads
		$output = `/bin/nice -n 19 $cmdline`;
		$exit_code = $?>>8;
		alarm(0);
	};
	if ($@) {
		# Timed out ...
		die unless $@ eq "alarm\n";   # propagate unexpected errors
			if ( -e $cacheFile ) {
				print_debug("$esx_plugin_name timed out after $timeout seconds, replaying cache file $cacheFile\n");
				replay_cache( $cacheFile );
			} else {
				print_debug("$esx_plugin_name timed outafter $timeout seconds, but no cache file available $cacheFile, setting UNKNOWN\n");
				# OK, too bad, no cache file we can draw on .. die crying
				print "CHECK_VMWARE_API.PL UNKNOWN: $esx_plugin_name timed out after $timeout seconds\n";
				exit 3;
			}
	}
	print_debug("got exit_code: $exit_code, output: $output\n");
	$output =~ s/^\s*|\s*$//g;
	$output .= "\n";
	# Sometimes the API fails with "Session file ended unexpectedly", "The session is not authenticated" - remove the session file if yes
	if ( $output =~ m/Session file ended unexpectedly|The session is not authenticated/ ) {
		if ( $cmdline =~ / -S ([^ ]+)/ ) {
			# Delete session file
			print_debug("API session not valid. Deleting the session file. Error was: $output\n");
			my $session_file = $1;
			unlink ( $session_file );
			write_file( $unknown_log , {append => 1}, "" . localtime() . ": " . 
			   "Session is not authenticated, unlinking session file: $session_file\n" . "(CMD: " . $cmdline . "\n" .
			   "Output: " . $output . ")\n"
			   ) ;
		}
	}
	
	# Sometimes check_vmware_api fails for mysterious VMware Perl API reasons.
	# Replay cache if this happens.
	# (A re-run of check could be considered instead, as these errors appears
	# to be often just transient failures).
	if (( $output =~ m/HOST(-VM)? (CPU|IO|MEM|NET|RUNTIME) Unknown error|SOAP Fault|SOAP request error|500 read failed|\/sdk\/webService|file ended unexpectedly|session is not authenticated|Host [^ ]+ does not exist| - (cpu|mem) usage=-| - io (read|write) latency=-/ ) && ( -e $cacheFile )) {
		print_debug("UNKNOWN error occurred, replaying the cache. Error was: $output\n");
		#write_file( $unknown_log , {append => 1}, "" . localtime() . ": " . $output . "(" . $cmdline . ")\n" ) ;
		replay_cache( $cacheFile );
	}
	use IO::File;
	my $cachefh = new IO::File;
	if ($cachefh->open( $cacheFile , "w" )) {
		$cachefh->printf("# Cached result of the execution of: %s\n", $cmdline);
		$cachefh->printf("$exit_code\n");
		$cachefh->printf( $output );
		$cachefh->close();
	} else {
		die ("Unable to open $cacheFile\n");
	}
	if ( $debug ) {
		my $output = read_file( $cacheFile );
		print_debug("Cache file updated, now contains:\n");
		print_debug("$output\n");
	}
	$output = trim_for_nsca_comp($output);
	print $output;
	exit $exit_code;
}

sub read_file {
	my($file) = @_;
	my $output = "";
	open(my $fh, '<', $file) or die("cannot open $file: $!");
	while(<$fh>) { $output .= $_ }
	close($fh);
	return $output;
}

sub replay_cache {
	my ($cacheFile) = @_;
	my @cacheStat = stat( "$cacheFile" );
	my @cache_data;
	my $cache_ok = 0;
	# Due to race conditions, it is possible that the cache file can be loaded up empty. Reload if so.
	for (my $try = 1; $try <= 3 ; $try++) {
		`cp $cacheFile "$cacheFile.non_valid"` if ( $try > 1 );
		open(DAT, $cacheFile) || die("Could not open cache file ($cacheFile)!");
		@cache_data=<DAT>;
		close(DAT);
#		if ( @cache_data[2] =~ m/CHECK_ESX/ ) {
			$cache_ok = 1;
			last;
#		}
		print_debug("Non-valid cache file content: \n" . join ("", @cache_data) .  "\n\n");
		print_debug("Got empty or non-valid cache file, retrying ..\n");
		sleep 2;
	}
	unless ( $cache_ok ) {
		print_debug("Cache file not OK, saving file and debug info to $cacheFile.non_valid\n");
		$cache_data[2] = "CHECK_VMWARE_API.PL: Cache file ($cacheFile) empty or not valid! Copy of cache file saved to $cacheFile.non_valid";
		write_file( "$cacheFile.non_valid" , {append => 1}, "\n\nDebug info:\n" . $debug_cache) unless $cache_ok;
	}
	my $check_result = $cache_data[2];
	$check_result = trim_for_nsca_comp($check_result);
	my $cache_status = " (Cache timestamp: " . localtime($cacheStat[9]) . ")";
	$check_result =~ s/\n//;
	$check_result =~ s/\||$/$cache_status\|/;
	print $check_result . "\n";
	exit $cache_data[1];
}

sub whoami {
	my $output;
	my $pid = open $output, q{-|}, 'whoami';
	while (<$output>) {
		chomp;
		return $_;
	}
	return;
}

sub trim_for_nsca_comp {
	my ($output) = @_;
	# Trim $output for NSCA compatibility - which means 512 bytes incl. perf data
	# Let's assume that cache + perf info is never more than ~150 bytes
	my @splitted = split(/\|/, $output);
	my $check_result = substr($splitted[0], 0, 350);
	my $perf_data = $splitted[1] || '';
	$output = $check_result . "|" . $perf_data;
	return $output;
}

sub print_debug {
	my ($msg) = @_;
	$debug_cache .= $msg;
	print $msg if $debug;
}

