#!/bin/bash
/bin/mv /var/spool/nagios/fluxios/service-perfdata /var/spool/nagios/fluxios/service-perfdata.$1
#/usr/libexec/pnp4nagios/process_perfdata.pl --bulk=/var/spool/pnp4nagios/service-perfdata.$1
