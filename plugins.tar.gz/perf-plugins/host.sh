#!/bin/bash
/bin/mv /var/spool/nagios/fluxios/host-perfdata /var/spool/nagios/fluxios/host-perfdata.$1
#/usr/libexec/pnp4nagios/process_perfdata.pl --bulk=/var/spool/pnp4nagios/host-perfdata.$1
