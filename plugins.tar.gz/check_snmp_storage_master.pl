#!/usr/bin/perl
# nagios: +epn
#
#
# Authors:      Dr. Peter Bieringer (bie)
#		Sven Nierlein (nie)
#
# Changes:
# 2008xxxx/sni: initial
# 20090916/bie: add -Pd to snmpwalk
# 20091030/bie: add use lib '/usr/lib/nagios/plugins' to use Nagios utils.pm
# 20091030/bie: skip drives with 0 storage size
# 20100714/bie: remove PROGNAME from output
# 20110330/bie: skip "devfs:" storage
# 20110420/sni: add exclude option
# 20131011/bie: add SNMPv3 support

=head1 NAME

nagios_check_snmp_storage.pl - checks a disk/swap/memory usage via snmp

=head1 SYNOPSIS

./nagios_check_snmp_storage.pl -H <ip_address> 
                                      [-p <path>]
                                      [-w warn_range]
                                      [-c crit_range]
                                      [-C community]
                                      [-P snmp version]
                                      [-t timeout]
                                      [-e <exclude path>]
                                      [-u <SNMPv3 user>]
                                      [-a <SNMPv3 auth proto>]
                                      [-A <SNMPv3 auth pass>]
                                      [-x <SNMPv3 priv proto>]
                                      [-X <SNMPv3 priv pass>]
                                      [-l <SNMPv3 security level>]
                                      [-h] [-v] [-V]

=head1 OPTIONS

=over 5

=item -h

    Print detailed help screen

=item -V

    Print version information

=item -H

    Host name or IP Address

=item -p

    Name of the disk, can be either a linux mount point like /var or a windows disk like c:
    If ommited, all disks of type hrStorageFixedDisk will be checked.
    Repeat this option to check several paths.
    Use "swap" for swap space checks and
    "memory" for Memory Checks.

=item -e

    Exclude disk by name. When no path (-p) is specified, you may use this option to exclude some mountpoints.
    Can be used more than once to exclude several mountpoints.

=item -P [1|2c]

    SNMP protocol version

=item -C

    Optional community string for SNMP communication (default is "public")

=item -w

    Warning threshold in percentage which will result in a WARNING status if the used space is higher than this value

=item -c

    Critical threshold in percentage which will result in a CRITICAL status if the used space is higher than this value

=item -t

    Seconds before connection times out (default: 10)

=item -v

    Show details for command-line debugging (Nagios may truncate output)

=back

=head1 DESCRIPTION

Checks disk usage via snmp.

The resulting performance date has the following format:
disklabel=free space;warning size;critical size;totalsize;percent used

This plugin uses the 'snmpget' and 'snmpwalk' command included with the NET-SNMP package.
if you don't have the package installed, you will need to download it from
http://net-snmp.sourceforge.net before you can use this plugin.

=cut

use warnings;
use strict;
use Getopt::Long;
use Pod::Usage;
use Data::Dumper;
use lib "/usr/lib/nagios/plugins/";
use lib "/usr/lib64/nagios/plugins/";
use utils qw(%ERRORS &print_revision);
$Data::Dumper::Sortkeys=1;

my $PROGNAME = 'nagios_check_snmp_storage';
my $VERSION  = '$Revision: 1 $';

################################################
# set defaults
my $unit          = "MB";
my $timeout       = 30;
my $snmpcommunity = "public";
my $snmpversion   = "2c";

################################################
# parse command line arguments
my ($opt_H,$opt_h,$opt_v,$opt_t,$opt_V,@opt_p,$opt_w,$opt_c,$opt_C,$opt_P,@opt_e, $opt_a, $opt_A, $opt_x, $opt_X, $opt_l, $opt_u);
Getopt::Long::Configure("no_ignore_case");
GetOptions(
   "H=s"        => \$opt_H,
   "v"          => \$opt_v,
   "h"          => \$opt_h,
   "t=i"        => \$opt_t,
   "V"          => \$opt_V,
   "p=s"        => \@opt_p,
   "w=s"        => \$opt_w,
   "c=s"        => \$opt_c,
   "C=s"        => \$opt_C,
   "P=s"        => \$opt_P,
   "e=s"        => \@opt_e,
   "a=s"        => \$opt_a,
   "A=s"        => \$opt_A,
   "x=s"        => \$opt_x,
   "X=s"        => \$opt_X,
   "l=s"        => \$opt_l,
   "u=s"        => \$opt_u,
);

########################################################
if ($opt_V) {
  print_revision($PROGNAME, $VERSION);
  exit $ERRORS{'OK'};
}

########################################################
# set a timeout
if(defined $opt_t) { $timeout = $opt_t; }
$SIG{ALRM} = sub{
  print "CRITICAL: timeout after $timeout seconds.";
  exit $ERRORS{"CRITICAL"}; 
};
alarm($timeout);

################################################
# just print the help message?
if(defined $opt_h) {
  pod2usage( { -verbose => 1 } );
  exit $ERRORS{'OK'};
}

################################################
# should we be verbose?
my $verbose  = 0;
if(defined $opt_v) {
  $verbose   = 1;
}

################################################
# check for a valid hostname
if(!defined $opt_H) {
  pod2usage( { -verbose => 1, -msg => "Error: -H <hostname> is a required option." } );
  exit $ERRORS{"UNKNOWN"}; 
}

################################################
# set snmp community
if(defined $opt_C) {
  $snmpcommunity = $opt_C;
}

################################################
# set snmp protocol version
if(defined $opt_P) {
  $snmpversion = $opt_P;
}

# extend with SNMPv3 if given
$snmpversion .= " -a '" . $opt_a . "'" if (defined $opt_a && $opt_a ne "");
$snmpversion .= " -A '" . $opt_A . "'" if (defined $opt_A && $opt_A ne "");
$snmpversion .= " -x '" . $opt_x . "'" if (defined $opt_x && $opt_x ne "");
$snmpversion .= " -X '" . $opt_X . "'" if (defined $opt_X && $opt_X ne "");
$snmpversion .= " -l '" . $opt_l . "'" if (defined $opt_l && $opt_l ne "");
$snmpversion .= " -u '" . $opt_u . "'" if (defined $opt_u && $opt_u ne "");

################################################
# try to find the disk information
my %diskData;
my @snmpwalkout;
my $snmpwalkcmd = "snmpwalk -Pd -r 3 -t 8 -v $snmpversion -c $snmpcommunity $opt_H  hrStorage";
print "executing: $snmpwalkcmd\n" if $verbose;
open(CL, "$snmpwalkcmd 2>&1|") or die("error executing snmpwalk: $!");
while(<CL>) {
  my $line = $_;
  push @snmpwalkout, $line;
  chomp($line);
  print "snmpwalk: $line\n" if $verbose;


  my($oid,$value) = split /\s+=\s+/, $line, 2;
  next if !defined $value;
  $value =~ s/^STRING:\s+//;
  $value =~ s/^INTEGER:\s+//;
  $value =~ s/^OID:\s+//;

  $oid   =~ s/^HOST-RESOURCES-MIB:://;
  if($oid =~ m/\.(\d+)$/) {
    my $nr = $1;
    $oid   =~ s/\.$nr$//;
    if($oid eq "hrStorageAllocationUnits") {
      $value =~ s/\s+Bytes//;
    }
    if($oid eq "hrStorageType") {
      $value =~ s/HOST-RESOURCES-TYPES:://;
    }
    $diskData{$oid}->{$nr} = $value;;
  }
}
close(CL);
my $rc = $?>>8;
if($rc != 0) {
  print "UNKNOWN - snmpwalk failed with rc $rc: ".join(" ", @snmpwalkout)."\n";
  exit $ERRORS{"UNKNOWN"}; 
}

################################################
print "diskdata:\n"      if $verbose;
print Dumper(\%diskData) if $verbose;

################################################
# did we find one?
if(!defined $diskData{'hrStorageIndex'}) {
  print "UNKNOWN - got no disk information from snmp\n";
  exit $ERRORS{"UNKNOWN"}; 
}

################################################
# should we check specified disks or all?
my %diskIdRef;
my $hasSuppliedPathToCheck = 1;
if(scalar @opt_p <= 0) {
  $hasSuppliedPathToCheck = 0;
} else {
  # just lowercase the userinput
  @opt_p = map(lc, @opt_p);
}

my $bind_mounts = {};
for my $id (keys %{$diskData{'hrStorageDescr'}}) {
  if(   $diskData{'hrStorageType'}->{$id} eq 'hrStorageFixedDisk'
     or $hasSuppliedPathToCheck
  ) {

    my $src;
    my($label) = split /\s+/, $diskData{'hrStorageDescr'}->{$id};
    if($diskData{'hrStorageDescr'}->{$id} =~ m/(.*)\s+mounted on:\s+(.*)$/) {
        $label  = $2;
        $src    = $1;
        $src    =~ s/\\$//;
        $src    =~ s/,$//;
        next if $src =~ m/^devfs:/;
    }
    $label     =~ s/\\$//;
    $label     =~ s/,$//;

    next if $label =~ m/^\/proc/;
    next if $label =~ m/^\/sys/;
    next if $label =~ m/^\/dev/;
    next if $label =~ m/^devfs:/;
    next if $label =~ m/\/kickstart\/images\//;

    $bind_mounts->{$label} = $src if defined $src;

    if($diskData{'hrStorageType'}->{$id} eq 'hrStorageRam') {
      $label = "Memory";
    }
    if($diskData{'hrStorageType'}->{$id} eq 'hrStorageVirtualMemory') {
      $label = "Swap";
    }
    if($diskData{'hrStorageType'}->{$id} eq 'hrStorageOther' and $diskData{'hrStorageDescr'}->{$id} eq "Memory Buffers") {
      $label = "Buffer";
    }

    $label = lc $label;

    if(!$hasSuppliedPathToCheck) {
      push @opt_p, $label;
    }
    $diskIdRef{$label} = $id;
  }
}

################################################
print "bind_mounts:\n"     if $verbose;
print Dumper($bind_mounts) if $verbose;

################################################
# iterate over the specified disks
my $exit = "OK"; 
my @pluginOutput;
my @perfData;
for my $disk (sort @opt_p) {

  print "\n$disk:\n" if $verbose;

  my $critical_value = "";
  my $warning_value  = "";

  if(!defined $diskIdRef{$disk}) {
    push @pluginOutput, "'$disk' not found";
    $exit = "UNKNOWN"; 
    next;
  }

  $disk = lc $disk;
  my $id = $diskIdRef{$disk};
  my $hrStorageAllocationUnits = $diskData{'hrStorageAllocationUnits'}->{$id};
  my $hrStorageSize            = $diskData{'hrStorageSize'}->{$id};
  my $hrStorageUsed            = $diskData{'hrStorageUsed'}->{$id};
  if ($hrStorageSize == 0) {
    # Storage has size of 0
    next;
  };

  # skip bind mounts unless direct path used
  if(!$hasSuppliedPathToCheck and defined $bind_mounts->{$disk}) {
    my $src = $bind_mounts->{$disk};
    my $found;
    for my $mnt (keys %{$bind_mounts}) {
      next if $disk eq $mnt;
      if($src =~ m/^$mnt/) {
        $found = $mnt;
      }
    }
    if(defined $found) {
      my $bid = $diskIdRef{$found};
      if(    $hrStorageAllocationUnits == $diskData{'hrStorageAllocationUnits'}->{$bid}
         and $hrStorageSize            == $diskData{'hrStorageSize'}->{$bid}
         and $hrStorageUsed            == $diskData{'hrStorageUsed'}->{$bid}
      ) {
        print "bound from $found\n" if $verbose;
        next;
      }
    }
  }

  # skip mounts from exclude list
  if(scalar @opt_e > 0) {
    my $found=0;
    for my $exclude (@opt_e) {
      if($disk =~ $exclude) {
        print "excluded by pattern: $exclude\n" if $verbose;
        $found++;
        last;
      }
    }
    if($found) {
      next;
    }
  }

  if($disk eq "memory" and defined $diskIdRef{"buffer"} and defined $diskData{'hrStorageUsed'}->{$diskIdRef{"buffer"}}) {
    my $bufferId   = $diskIdRef{"buffer"};
    my $bufferSize = $diskData{'hrStorageAllocationUnits'}->{$bufferId} + $diskData{'hrStorageUsed'}->{$bufferId};
    print "removing buffer from memory usage: $bufferSize\n" if $verbose;
    $hrStorageUsed = $hrStorageUsed - $bufferSize;
  }

  if($verbose) {
    print "hrStorageAllocationUnits: $hrStorageAllocationUnits\n";
    print "hrStorageSize:            $hrStorageSize\n";
    print "hrStorageUsed:            $hrStorageUsed\n";
  }

  my $usedPercentage = sprintf("%.1f", $hrStorageUsed / $hrStorageSize * 100);
  my $totalSize      = $hrStorageSize * $hrStorageAllocationUnits;
  my $freeSpace      = ($hrStorageSize - $hrStorageUsed )* $hrStorageAllocationUnits;
  my $usedSpace      = $totalSize - $freeSpace;

  if($verbose) {
    print "totalSize: $hrStorageSize * $hrStorageAllocationUnits\n";
    print "freeSpace: ($hrStorageSize - $hrStorageUsed )* $hrStorageAllocationUnits\n";
    print "usedSpace: $totalSize - $freeSpace\n";
  }
  ################################################
  # convert values to human readable sizes
  $freeSpace      = convertValuesToUnit($freeSpace);
  $usedSpace      = convertValuesToUnit($usedSpace);
  $totalSize      = convertValuesToUnit($totalSize);

  ################################################
  # check warning threshold
  if(defined $opt_w) {
    $opt_w =~ s/%//;
    $warning_value = sprintf("%.0f", $totalSize * $opt_w/100);
  
    if($usedSpace >= $warning_value) {
      if($exit eq "OK") {
        $exit = "WARNING"; 
      }
    }
  }

  ################################################
  # check critical threshold
  if(defined $opt_c) {
    $opt_c =~ s/%//;
    $critical_value = sprintf("%.0f", $totalSize * $opt_c/100);
  
    if($usedSpace >= $critical_value) {
      $exit = "CRITICAL"; 
    }
  }

  ################################################
  # calculate performance data
  ### Correctd For Windows Disk Perf Data ##
    $disk =~ s/\\//g;
  push @perfData,    "$disk=$usedSpace$unit;$warning_value;$critical_value;$totalSize;$usedPercentage";

  ################################################
  # generate the plugin output
  push @pluginOutput, "$disk $freeSpace$unit (used ".sprintf("%.0f", $usedPercentage)."%)";
}

print "$exit - free space: ".join(", ", @pluginOutput)."|".join(" ", @perfData);
exit $ERRORS{$exit}; 

################################################
# convert a Byte value to MegaByte
sub convertValuesToUnit {
  my $value = shift;
  $value = sprintf("%.1f", $value / 1024 / 1024);
  return($value);
}
