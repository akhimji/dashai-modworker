#!/bin/bash
############################################
#                                          #
#   Windows services monitoring via SNMP   #
#   for Nagios                             #
#                                          #
#   Author: Oscar Manuel Gómez Senovilla   #
#   27/10/2009                             #
#                                          #
############################################

# This program is released using GPLv3 licensing terms

### Variables ###

## Initialize variables. Do not modify
SERVER=$1
shift
COMMUNITY=$1
shift
WARNING=$1
shift
CRITICAL=$1
shift
PARAMS="$@"


## Customizable variables

# Full path for temporary snmp files
SNMPFILE=/tmp/check_snmp_${SERVER}

# How minutes old should be $SNMPFILE to recreate it
DELAY=10

# Some L10N. First, define custom string for lang messages at Nagios UI.
# Mine is Spanish (ES)
UILANG="ES"
# Second, if $UILANG != "EN", define your $UILANG with a number
ES=1
# Then, define MSG_USAGE[${UILANG}] variable
# Last, assign the translation for the word "Usage" to your $UILANG.
MSG_USAGE[EN]="Usage"
MSG_USAGE[ES]="Uso"

# Uncomment for debugging
#DEBUG=1

## End of customizable params

## Nagios state constants. Not to be customized
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3
STATE_DEPENDENT=4
STATE_ERROR=255
STATE[${STATE_OK}]="OK"
STATE[${STATE_WARNING}]="WARNING"
STATE[${STATE_CRITICAL}]="CRITICAL"
STATE[${STATE_UNKNOWN}]="UNKNOWN"
STATE[${STATE_DEPENDENT}]="DEPENDENT"
STATE[${STATE_ERROR}]="ERROR"

## End of nagios constants

### End of variables


function add_output_line()
{
    if [[ ${OUTPUT} ]];then
	OUTPUT="$OUTPUT <br /> "
    fi
    OUTPUT="${OUTPUT}$@"
}


function check_debug()
{
#    set -x
    if [[ $DEBUG ]];then
	set -x
    else
	set +x
    fi
}

function check_snmp_file()
{
    if [[ -f ${SNMPFILE} ]];then
        if [[ ! $(find /tmp -mmin +${DELAY} -wholename ${SNMPFILE} ) ]];then
    	    echo "The file ${SNMPFILE} was created less than ${DELAY} minutes ago">/dev/null
        else
	    echo "The file ${SNMPFILE} was created more than ${DELAY} minutes ago">/dev/null
	    create_snmp_file
	fi
    else
	create_snmp_file
    fi
}

function conv_size()
{
    # Convert an integer to KB, MB, GB, or TB
    TB=$(( $1 / 1024 ** 4 ))
    GB=$(( $1 / 1024 ** 3 ))
    MB=$(( $1 / 1024 ** 2 ))
    KB=$(( $1 / 1024 ))
    scale=3
    if (( $1 < 999 ));then
	UNITS="bytes"
	DIV=0
	scale=0
    elif (( KB < 999 ));then
	UNITS="KiB"
	DIV=1
    elif (( MB < 999 ));then
	UNITS="MiB"
	DIV=2
    elif (( GB < 999 ));then
	UNITS="GiB"
	DIV=3
    else
	UNITS="TiB"
	DIV=4
    fi
    CALC="$1 / 1024 ^ $DIV"
    RESULT=$(echo "scale=$scale;$CALC"|bc -l)
    echo "${RESULT} ${UNITS}"
}


function create_snmp_file()
{
    T=$(snmpwalk -v 1 -t 10 -c $COMMUNITY $SERVER) || exit $STATE_ERROR
    echo "$T" > ${SNMPFILE}
    unset T
}

function get_cpu_descriptors()
{
    # Returns a number taking the drive letter
    get_descriptor_param "hrSWRunPerfCPU"
    check_debug
}

function get_descriptor_index()
{
    if [[ -z ${RESULT} ]];then
	RESULT=$(grep "^${MIB_TYPE}::${SUB_FILTER}" ${SNMPFILE})
    fi
    echo "$1"|cut -d. -f2|awk '{ print $1 }'
}

function get_descriptor_param()
{
    if [[ -z ${RESULT} ]];then
	RESULT=$(grep "^${MIB_TYPE}::${SUB_FILTER}" ${SNMPFILE})
    fi
    echo "$RESULT"|grep "$1 "|cut -d= -f2|cut -d: -f2-|cut -d\  -f${2:-2-}
}

function get_disk_descriptors()
{
    # Returns a descriptor number taking the drive letter
    if [[ -z $DISKS ]];then
	LINES=$(echo "$RESULT"|grep hrStorageDescr|grep -i "Serial Number")
	get_descriptor_index "$LINES"
    else
	for DISK in ${DISKS};do
	    LINE=$(echo "$RESULT"|grep hrStorageDescr|grep -i " ${DISK}:")
	    get_descriptor_index "$LINE"
	done
    fi
    check_debug
}


function get_mem_descriptors()
{
    # Returns a number taking the drive letter
    if [ -z ${MEMTYPES} ];then
        LINES=$(echo "$RESULT"|grep hrStorageDescr|grep -i "Memory")
	echo "$LINES"|cut -d. -f2|awk '{ print $1 }'
    else
	for MEMTYPE in ${MEMTYPES};do
    	    LINE=$(echo "$RESULT"|grep hrStorageDescr|grep -i " ${MEMTYPE} Memory")
	    echo "$LINE"|cut -d. -f2|awk '{ print $1 }'
	done
    fi
    check_debug
}


function get_process_descriptors()
{
    # Returns a number taking the process name
    LINES=$(echo "$RESULT"|grep -w "${EXENAME}")
    echo "$LINES"|cut -d. -f2|awk '{ print $1 }'
    check_debug
}


function get_storage_drive()
{
    for D in $@;do
	get_descriptor_param "hrStorageDescr.$DESCRIPTOR" 2|cut -d: -f1
    done
    check_debug
}



function get_storage_size()
{
    for D in $@;do
	get_descriptor_param "hrStorageSize.$DESCRIPTOR"
    done
    check_debug
}

function get_storage_units()
{
    for D in $@;do
	LINE=$(echo "$RESULT"|grep "hrStorageAllocationUnits.$DESCRIPTOR ")
	echo $LINE|cut -d= -f2|cut -d: -f2|awk '{ print $1 }'
    done
    check_debug
}

function get_storage_used()
{
    for D in $@;do
	LINE=$(echo "$RESULT"|grep "hrStorageUsed.$DESCRIPTOR ")
	echo $LINE|cut -d= -f2|cut -d: -f2
    done
    check_debug
}


function print_cpu_usage()
{
    MIB_TYPE="HOST-RESOURCES-MIB"
    SUB_FILTER="hrSWRunPerfCPU"
    RESULT=$(grep "^${MIB_TYPE}::${SUB_FILTER}" ${SNMPFILE})
    DISKS="$PARAMS"
    
    DESCRIPTORS=$(get_cpu_descriptors)

    for DESCRIPTOR in $DESCRIPTORS;do
	echo $DESCRIPTOR
    done

}

function print_disk_usage()
{
    MIB_TYPE="HOST-RESOURCES-MIB"
    SUB_FILTER="hrStorage"
    RESULT=$(grep "^${MIB_TYPE}::${SUB_FILTER}" ${SNMPFILE})
    DISKS="$PARAMS"
    
    DESCRIPTORS=$(get_disk_descriptors)

    if [[ $DESCRIPTORS ]];then
        for DESCRIPTOR in $DESCRIPTORS;do
    	    SIZE=$(get_storage_size $DESCRIPTOR)
            if (( SIZE > 0 ));then
		    UNITS=$(get_storage_units $DESCRIPTOR)
	        USED=$(get_storage_used $DESCRIPTOR)
		DRIVE=$(get_storage_drive $DESCRIPTOR)
    	        TOTALSIZE=$(( SIZE * UNITS ))
		TOTALUSED=$(( USED * UNITS ))
		TOTALFREE=$(( TOTALSIZE - TOTALUSED ))
	        CONVSIZE=$(conv_size ${TOTALSIZE})
		CONVUSED=$(conv_size ${TOTALUSED})
		CONVFREE=$(conv_size ${TOTALFREE})
	        PERCENTUSED=$(( (( TOTALUSED * 100 )) / TOTALSIZE ))
		TEMP_STATUS=${STATE_OK}
	        if ((  ${PERCENTUSED} < ${CRITICAL} ));then
		    if (( ${PERCENTUSED} >= ${WARNING} ));then
	    	        TEMP_STATUS=${STATE_WARNING}
	    	    fi
		else
		    TEMP_STATUS=${STATE_CRITICAL}
		fi
		if (( TEMP_STATUS > EXIT_STATUS ));then
		    EXIT_STATUS=${TEMP_STATUS}
	        fi
		LINE=$(print_usage ${DRIVE}:)
		add_output_line "${LINE}"
	    fi
	done
    else
	EXIT_STATUS=${STATE_UNKNOWN}
	add_output_line "${STATE[${EXIT_STATUS}]} No existe $DISKS:"
    fi

}

function print_mem_usage()
{
    MIB_TYPE="HOST-RESOURCES-MIB"
    SUB_FILTER="hrStorage"
    RESULT=$(grep "^${MIB_TYPE}::${SUB_FILTER}" ${SNMPFILE})
    MEMTYPE="$PARAMS"
    
    DESCRIPTORS=$(get_mem_descriptors)

    for DESCRIPTOR in $DESCRIPTORS;do
	SIZE=$(get_storage_size $DESCRIPTOR)
        if (( SIZE > 0 ));then
	    UNITS=$(get_storage_units $DESCRIPTOR)
	    USED=$(get_storage_used $DESCRIPTOR)
	    DRIVE=$(get_storage_drive $DESCRIPTOR)
	    TOTALSIZE=$(( SIZE * UNITS ))
	    TOTALUSED=$(( USED * UNITS ))
	    TOTALFREE=$(( TOTALSIZE - TOTALUSED ))
	    CONVSIZE=$(conv_size ${TOTALSIZE})
	    CONVUSED=$(conv_size ${TOTALUSED})
	    CONVFREE=$(conv_size ${TOTALFREE})
	    PERCENTUSED=$(( (( TOTALUSED * 100 )) / TOTALSIZE ))
	    TEMP_STATUS=${STATE_OK}
	    if ((  ${PERCENTUSED} < ${CRITICAL} ));then
	        if (( ${PERCENTUSED} >= ${WARNING} ));then
	    	    TEMP_STATUS=${STATE_WARNING}
	    	fi
	    else
		TEMP_STATUS=${STATE_CRITICAL}
	    fi
	    if (( TEMP_STATUS > EXIT_STATUS ));then
		EXIT_STATUS=${TEMP_STATUS}
	    fi
	    LINE=$(print_usage ${DRIVE}:)
	    add_output_line "${LINE}"
	fi
    done

}

function print_process()
{
    MIB_TYPE="HOST-RESOURCES-MIB"
    SUB_FILTER="hrSWRun"
    RESULT=$(grep "^${MIB_TYPE}::${SUB_FILTER}" ${SNMPFILE})
    
    # It must be in the form C:\\Archivos de programa\\path to program\\program.exe [<params>}
    # But better if $PARAMS is !program.exe!C:\Archivos de programa\\ruta a cosa![<params>]
    # Then, we lookup "program.exe"

    EXENAME=$1
    shift
    EXEPATH=$(echo $1|sed 's|\\|/|g'|sed 's|//|/|g')
    shift
    EXEPARAMS="$@"
    
    DESCRIPTORS=$(get_process_descriptors)
    # Partial output of snmp to be parsed
    # For a given descriptor 1488
    ## grep -w 1488 check_snmp_ssdmz009
    #HOST-RESOURCES-MIB::hrSWRunIndex.1488 = INTEGER: 1488
    #HOST-RESOURCES-MIB::hrSWRunName.1488 = STRING: "armonitor.exe"
    #HOST-RESOURCES-MIB::hrSWRunID.1488 = OID: SNMPv2-SMI::zeroDotZero
    #HOST-RESOURCES-MIB::hrSWRunPath.1488 = STRING: "C:\\AR System\\"
    #HOST-RESOURCES-MIB::hrSWRunParameters.1488 = ""
    #HOST-RESOURCES-MIB::hrSWRunType.1488 = INTEGER: application(4)
    #HOST-RESOURCES-MIB::hrSWRunStatus.1488 = INTEGER: running(1)
    #HOST-RESOURCES-MIB::hrSWRunPerfCPU.1488 = INTEGER: 9
    #HOST-RESOURCES-MIB::hrSWRunPerfMem.1488 = INTEGER: 2888 KBytes
    
    # Since there can be several equal $EXENAME, we check everything matches

    EXIT_STATUS=${STATE_ERROR}
    for DESCRIPTOR in $DESCRIPTORS;do
	# Buscamos la ruta
	PATH0=$(get_descriptor_param "hrSWRunPath.${DESCRIPTOR}"|sed 's|\\|/|g'|sed 's|//|/|g')
	#PATH0=$(grep "hrSWRunPath.${DESCRIPTOR} =" ${SNMPFILE}|cut -d= -f2-|cut -d: -f2-)

	if [[ ${PATH0} == \"${EXEPATH}\" ]];then
#	    echo "Checking params..."
	    EXEPARAMS0=$(get_descriptor_param "hrSWRunParameters.${DESCRIPTOR} ="|sed 's/\\\\/\\/g')

	    if [[ $EXEPARAMS0 ]];then
		EXEPARAMS1=$(echo $EXEPARAMS0|sed 's:\\:\:g' 2>/dev/null)
	    fi
	    if [[ ${EXEPARAMS1} == "${EXEPARAMS}" ]];then
#		echo "It IS the process we are looking for"
		EXESTATUS=$(get_descriptor_param "hrSWRunStatus.${DESCRIPTOR}"|cut -d: -f2-)
		case $EXESTATUS in
		    "running(1)")
			# The process is running
			EXIT_STATUS=${STATE_OK}
			;;
		    *)
			EXIT_STATUS=${STATE_CRITICAL}
			;;
		esac
		OUTPUT="${STATE[${EXIT_STATUS}]}: ${EXENAME}(${DESCRIPTOR}): ${EXESTATUS}"
		break
	    fi
	fi
    done

}


function print_usage()
{
	echo "${STATE[${TEMP_STATUS}]}: $@ ${MSG_USAGE[$UILANG]}: ${CONVUSED}/${CONVSIZE} (${PERCENTUSED}%)"
}

function show_help()
{
    # Function to be run if -h is used, as standard plugins do
    echo "
    Syntax: Depends on the way it is run (create symlinks to check_snmp.sh if you didn't):
        - check_snmp_cpu: <host|ip> <community>
        - check_snmp_disk: <host|ip> <community> <warning> <critical> <drive list>
          Drive list is separated by whitespace and no colon, i.e. "C D E". If empty, all disks are checked.
        - check_snmp_mem: <host|ip> <community>
        - check_snmp_process: <host|ip> <community> <program> [args]
          Program should be just like the process has been run (full path or no path if called without path).
          The path should replace any original '\' with '/', so you can use c:/windows/system32/explorer.exe
          as program to be checked. Args are to distinguish when program can be run with several args, so
          we can choose the right one, like svchost.exe.
          "
}

if [[ -z $SERVER || $SERVER = "-h" ]];then
    show_help
    exit ${STATE_UNKNOWN}
fi

check_snmp_file
check_debug


EXIT_STATUS=${STATE_OK}

MIB_TYPE="HOST-RESOURCES-MIB"
SUB_FILTER="hrStorage"

BASENAME=$(basename $0)

# Check how we are called (proper symlinks must exist)
case $BASENAME in
    check_snmp_cpu*)
	print_cpu_usage
	;;
    check_snmp_disk*)
	print_disk_usage
	;;
    check_snmp_mem*)
	print_mem_usage
	;;
    check_snmp_process*)
	print_process "$WARNING" "$CRITICAL" $PARAMS
	;;

esac
	

echo "$OUTPUT"

exit ${EXIT_STATUS}

