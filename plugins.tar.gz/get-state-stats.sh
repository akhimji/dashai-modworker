#!/bin/bash

printf 'GET hosts \nColumns: host_num_services_hard_ok \n' | nc localhost 6557 > /tmp/temp
OKs=0;while read p; do OKs=$(( $OKs + $p )); done < /tmp/temp

printf 'GET hosts \nColumns: host_num_services_hard_warn \n' | nc localhost 6557 > /tmp/temp
WARNs=0;while read p; do WARNs=$(( $WARNs + $p )); done < /tmp/temp

printf 'GET hosts \nColumns: host_num_services_hard_crit \n' | nc localhost 6557 > /tmp/temp
CRITs=0;while read p; do CRITs=$(( $CRITs + $p )); done < /tmp/temp

printf 'GET hosts \nColumns: host_num_services_hard_unknown \n' | nc localhost 6557  > /tmp/temp
UNKs=0;while read p; do UNKs=$(( $UNKs + $p )); done < /tmp/temp

#echo $OKs
#echo $WARNs
#echo $CRITs
#echo $UNKs
#PING ok - Packet loss = 0%, RTA = 0.80 ms | percent_packet_loss=0, rta=0.80
OUTPUT='OK Count='$OKs' , WARN Count='$WARNs', CRIT Count='$CRITs', UNKNOWN Count='$UNKs' | OK='$OKs' WARN='$WARNs' CRITICAL='$CRITs' UNKNOWNS='$UNKs

echo $OUTPUT
